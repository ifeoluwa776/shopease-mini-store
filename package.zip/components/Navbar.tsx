"use client";

import React from "react";
import Link from "next/link";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { cart } = useCart();

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white shadow-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="text-xl font-bold tracking-tight text-slate-900">
              ShopEase
            </Link>
            <Link href="/" className="text-sm font-medium text-slate-600 hover:text-slate-900">
              Home
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <Link 
              href="/cart" 
              className="group flex items-center p-2 text-slate-600 hover:text-slate-900"
            >
              <span className="text-sm font-medium">Cart</span>
              <span className="ml-2 rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-700 group-hover:bg-slate-200">
                {cart.length}
              </span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
