"use client";

import React from "react";
import { useCart } from "../context/CartContext";

type Product = {
  id: number;
  title: string;
  description: string;
  price: number;
  category: string;
  image: string;
  rating: number;
  inStock: boolean;
};

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white p-4 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      {/* Image Container */}
      <div className="aspect-square w-full overflow-hidden rounded-xl bg-slate-100 flex items-center justify-center p-4">
        <img 
          src={product.image} 
          alt={product.title} 
          className="h-full w-full object-contain object-center max-h-48 transition-transform duration-300 group-hover:scale-105"
        />
      </div>

      {/* Product Information */}
      <div className="flex flex-1 flex-col pt-4">
        <h3 className="text-sm font-semibold text-slate-800 line-clamp-1 mb-1">
          {product.title}
        </h3>
        <p className="text-xs text-slate-500 line-clamp-2 mb-4 flex-1">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mt-auto">
          <span className="text-lg font-bold text-emerald-600">${product.price}</span>
          <button 
            onClick={() => addToCart(product)}
            className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white shadow transition-colors hover:bg-slate-800 active:scale-95"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
