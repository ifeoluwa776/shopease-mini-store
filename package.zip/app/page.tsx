"use client";

import React from "react";
import { useCart } from "../context/CartContext";

export default function CartPage() {
  const { cart, removeFromCart, total } = useCart();

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8 min-h-screen bg-gray-50">
      <h1 className="text-3xl font-bold tracking-tight text-gray-900 mb-8">Your Shopping Cart</h1>

      {cart.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
          <p className="text-gray-500 mb-4">Your cart is empty.</p>
          <a href="/" className="inline-flex items-center rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white shadow hover:bg-slate-800">
            Continue Shopping
          </a>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Cart Items List */}
          <div className="bg-white rounded-2xl border border-gray-200 divide-y divide-gray-100 shadow-sm overflow-hidden">
            {cart.map((item, index) => (
              <div key={`${item.id}-${index}`} className="flex p-6 items-center justify-between gap-6">
                {/* Fixed Size Image Container */}
                <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-xl border border-gray-100 bg-gray-50 p-2 flex items-center justify-center">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="h-full w-full object-contain"
                  />
                </div>

                {/* Product Metadata Details */}
                <div className="flex flex-1 flex-col">
                  <h3 className="text-base font-semibold text-gray-900 line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="mt-1 text-sm font-medium text-emerald-600">${item.price}</p>
                </div>

                {/* Remove Button Action */}
                <button
                  onClick={() => removeFromCart(item.id)}
                  className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-red-600 shadow-sm transition-colors hover:bg-red-50 hover:border-red-200 active:scale-95"
                >
                  Remove
                </button>
              </div>
            ))}
          </div>

          {/* Checkout & Total Box Layout */}
          <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Balance</p>
              <p className="text-2xl font-bold text-gray-900">${total.toFixed(2)}</p>
            </div>
            <button className="rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white shadow transition-colors hover:bg-slate-800 active:scale-95">
              Proceed to Checkout
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
